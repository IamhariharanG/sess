{
    'name': 'Sess Plugin',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'DESIGN PLAN',
    'depends': ['base','contacts','sale','sess_inherit_service'],
    'data': [
          
          'security/ir.model.access.csv',
          'views/design_plan.xml',
          'views/design_input.xml',
          'views/design_output.xml',
          'views/designdata_sheet.xml',
          'views/design_dev_review.xml',
          'views/design_verification.xml',
          'views/design_validation.xml',
          'views/design_change_note.xml',
          'views/project_inherit.xml',
          'views/masters.xml',
          
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
