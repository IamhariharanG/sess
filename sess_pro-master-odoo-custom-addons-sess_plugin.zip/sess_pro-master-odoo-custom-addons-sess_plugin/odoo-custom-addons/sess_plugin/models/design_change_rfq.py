from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class DesignChangeNote(models.Model):
    _name = 'design.change.note'
    _rec_name = 'ref'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Change Note" 
   
    ref = fields.Char(string="Reference",required=True,track_visibility='onchange')
    date = fields.Date(string="Date",track_visibility='onchange')
    project_id = fields.Many2one("project.project",string="Project Name",track_visibility='onchange')
    partner_id = fields.Many2one("res.partner",string="Customer Name",track_visibility='onchange')
    requester_id = fields.Many2one("res.users",string="Requested By",track_visibility='onchange')
    department = fields.Char(string="Department",track_visibility='onchange')
    machine_description = fields.Char(string="Machine Description",track_visibility='onchange')
    initiated_by = fields.Selection([('sess','SESS'),('customer','Customer')],string="Change Initiated By",track_visibility='onchange')
    
    #nature of change
    is_material = fields.Boolean(string="Material Change",track_visibility='onchange')
    is_method = fields.Boolean(string="Method Change",track_visibility='onchange')
    is_design = fields.Boolean(string="Design Change",track_visibility='onchange')
    is_dimensional = fields.Boolean(string="Dimensional Change",track_visibility='onchange')
    is_process = fields.Boolean(string="Process Change",track_visibility='onchange')
    
    change_description = fields.Text(string="Change Description",track_visibility='onchange')
    benifit = fields.Text(string="Benifit",track_visibility='onchange')
    comment = fields.Text(string="Comment",track_visibility='onchange')
    
    status = fields.Selection([('draft','Draft'),('apprroved','Approved'),('reject','Reject')],string="Status",track_visibility='onchange',default = 'draft')
    
    #drawing status
    is_received_revised_drawing = fields.Boolean(string="Is Received Revised Drawing",track_visibility='onchange')
    drawing_revised_no = fields.Char(string="Drawing Revised Number",track_visibility='onchange')
    attachment_ids = fields.Many2many("ir.attachment",string="Attachment")
    
    #inherit
    sale_id=fields.Many2one('sale.order',string="Sale Order",track_visibility='onchange')

    #one2many
    document_revised_line = fields.One2many("design.revise.line","change_id",string="Relevant documents to update",ondelete='cascade')
    
    def action_approve(self):
        self.status = "apprroved"
    
    def action_reject(self):
        self.status = "reject"
    
class DesignReviseLine(models.Model):
    _name = 'design.revise.line'
    _rec_name = "description"
    
    change_id = fields.Many2one("design.change.note",string="Change ID",ondelete='cascade')
    s_no = fields.Integer(string="S.No",compute='serial_number_data',store=True)
    description = fields.Char(string="Document Description")
    yes = fields.Boolean(string="Yes")
    no = fields.Boolean(string="No")
    na = fields.Boolean(string="NA")
    rev_no = fields.Char(string="If Yes, Revised Number")
    date = fields.Date(string="Date")

    @api.depends('change_id.document_revised_line')
    def serial_number_data(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.change_id.document_revised_line:
                no +=1
                line.s_no = no
    
    