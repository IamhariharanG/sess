from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

  
class Designplan(models.Model):
    _name = 'design.plan'
    _rec_name="offer_no"
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Plan"

    #form
    offer_no=fields.Char(string="Offer No",required=True,track_visibility='onchange')
    offer_date=fields.Date(string="Offer Date",track_visibility='onchange')
    ref=fields.Char(string="REF",required=False,track_visibility='onchange')
    responsible_id=fields.Many2one('res.users',string="Responsible Person",track_visibility='onchange')
    po_no=fields.Char(string="P.O.No",track_visibility='onchange')
    po_date=fields.Date(string="P.O.Date",track_visibility='onchange')
    machine_id = fields.Many2one('machine.master',string="Equipment Name",track_visibility='onchange')
    project_id=fields.Many2one('project.project',string="Project Name",track_visibility='onchange')
    partner_id=fields.Many2one('res.partner',string="Customer Name",track_visibility='onchange')
    status = fields.Selection([('in_progress','In Progress'),('complete','Completed')],string="Status",default = 'in_progress',track_visibility='onchange')
    
    #approval
    prepare_id=fields.Many2one('res.users',string="Prepared by:",track_visibility='onchange')
    prepare_date=fields.Date(string="Date",track_visibility='onchange')
    prepare_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    approve_id=fields.Many2one('res.users',string="Approved by:",track_visibility='onchange')
    approve_date=fields.Date(string="Date",track_visibility='onchange')
    approve_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    
    #inherit
    sale_id=fields.Many2one('sale.order',string="Sale Order",track_visibility='onchange')

    #one2many
    design_plan_line_ids=fields.One2many('design.plan.line','plan_id',string='Design Line',ondelete='cascade')

    def action_approve(self):
        self.status = "complete"
        self.project_id.plan_status = "complete"

        if self.machine_id :
            orm = self.env['machine.master'].search([('id', '=', self.machine_id.id),('machine_type','=', 'dispatch_machine'),('partner_id','=',self.partner_id.id)])
            orm.write({'customer_po_no': self.po_no,
                       'customer_po_date' : self.po_date,
                       })
        else:
            pass


    
    # def action_reject(self):
    #     self.status = "reject"
    
    @api.onchange('offer_no')
    def check_offer_no(self):
        for rec in self:
            offer_len = self.env['design.plan'].search([('offer_no', '=', rec.offer_no)])
            if len(offer_len) >=1:
                raise ValidationError('Already Offer No Exists !')

class Designplanline(models.Model):
    _name = 'design.plan.line'

    plan_id=fields.Many2one('design.plan',string="Plan Id",ondelete='cascade')
    s_no=fields.Integer(string="S No",compute='serial_number_data',store=True)
    sequence_activity_id = fields.Many2one('plan.input',string= 'Sequence Of Activities')
    sequence_activities=fields.Char(string="Sequences")
    start_plan_date=fields.Date(string="Plan Start Date")
    start_actual_date=fields.Date(string="Actual Start Date")
    finish_plan_date=fields.Date(string="Plan Finish Date")
    finish_actual_date=fields.Date(string="Actual Finish Date")
    comments=fields.Char(string="Comments")


    @api.depends('plan_id.design_plan_line_ids')
    def serial_number_data(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.plan_id.design_plan_line_ids:
                no +=1
                line.s_no = no
    

            
            
            
    
     