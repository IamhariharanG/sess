from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class DesignDevelopmentReview(models.Model):
    _name = 'design.develop.review'
    _rec_name = 'ref'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Development Review" 
   
    ref = fields.Char(string="Reference",required=True,track_visibility='onchange')
    offer_no = fields.Char('No')
    offer_no_id = fields.Many2one('design.plan',string="Offer No",track_visibility='onchange',ondelete='cascade')
    po_no = fields.Char(string="PO No",track_visibility='onchange')
    offer_date = fields.Date(string="Offer Date",track_visibility='onchange')
    po_date = fields.Date(string="PO Date",track_visibility='onchange')
    machine_id = fields.Many2one('machine.master',string="Equipment Name",track_visibility='onchange')
    date = fields.Date(string="Date",track_visibility='onchange')
    project_id = fields.Many2one("project.project",string="Project Name",track_visibility='onchange')
    partner_id = fields.Many2one("res.partner",string="Customer Name",track_visibility='onchange')
    status = fields.Selection([('draft','Draft'),('prepare','Prepared'),('approved','Approved')],string="Status",default="draft",track_visibility='onchange',)

    #approval
    prepared_id = fields.Many2one("res.users",string="Prepared By",track_visibility='onchange')
    prepared_by_sign = fields.Binary(string="Signature",track_visibility='onchange')
    approved_id = fields.Many2one("res.users",string="Approved By",track_visibility='onchange')
    approved_by_sign = fields.Binary(string="Signature",track_visibility='onchange')
    
    #inherit
    sale_id=fields.Many2one('sale.order',string="Sale Order",track_visibility='onchange')

    #one2many
    review_line = fields.One2many("design.review.line","review_id",string="Review",ondelete='cascade')
    
    def action_approve(self):
        self.status = "approved"
    
    def action_prepare(self):
        self.status = "prepare"
   

    def _check(self):
        date = datetime.now()
        
        
    
class DesignReviewLine(models.Model):
    _name = "design.review.line"
    _rec_name = "detail"
    
    review_id = fields.Many2one("design.develop.review",string="Review ID",ondelete='cascade')
    s_no = fields.Integer(string="SI No",compute='serial_number_data',store=True)
    detail = fields.Char(string="Details")
    status = fields.Selection([('a','A'),('na','NA')],string="Status")
    date = fields.Date(string="Date")
    responsible_id = fields.Many2one("res.users",string="Responsibility")
    
    @api.depends('review_id.review_line')
    def serial_number_data(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.review_id.review_line:
                no +=1
                line.s_no = no