from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

  
class Designinput(models.Model):
    _name = 'design.input'
    _rec_name="ref"
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Input"

    #form
    offer_no = fields.Char('No')
    offer_no_id = fields.Many2one('design.plan',string="Offer No",track_visibility='onchange',ondelete='cascade')
    offer_date=fields.Date(string="Offer Date",track_visibility='onchange')
    ref=fields.Char(string="REF",required=True,track_visibility='onchange')
    po_no=fields.Char(string="P.O.No",track_visibility='onchange')
    po_date=fields.Date(string="P.O.Date",track_visibility='onchange')
    machine_id = fields.Many2one('machine.master',string="Equipment Name",track_visibility='onchange')
    project_id=fields.Many2one('project.project',string="Project Name",track_visibility='onchange')
    partner_id=fields.Many2one('res.partner',string="Customer Name",track_visibility='onchange')
    status = fields.Selection([('draft','Draft'),('apprroved','Approved'),('reject','Reject')],string="Status",track_visibility='onchange',default = 'draft')
    
    #approval
    prepare_id=fields.Many2one('res.users',string="Prepared by:",track_visibility='onchange')
    prepare_date=fields.Date(string="Date",track_visibility='onchange')
    prepare_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    approve_id=fields.Many2one('res.users',string="Approved by:",track_visibility='onchange')
    approve_date=fields.Date(string="Date",track_visibility='onchange')
    approve_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    
    #inherit
    sale_id=fields.Many2one('sale.order',string="Sale Order",track_visibility='onchange')

    #one2many
    design_input_line_ids=fields.One2many('design.input.line','input_id',string='Design Line',ondelete='cascade')

    def action_approve(self):
        self.status = "apprroved"
    
    def action_reject(self):
        self.status = "reject"

class Designinputline(models.Model):
    _name = 'design.input.line'

    input_id=fields.Many2one('design.input',string="Input Id",ondelete='cascade')
    s_no=fields.Integer(string="S No",compute='serial_number_datas',store=True)
    input=fields.Char(string="Input Value")
    input_new_id = fields.Many2one('design.input.plan',string='Inputs')
    source_input=fields.Char(string="Source of Input ")
    specification=fields.Char(string="Specification")
    remarks=fields.Char(string="Remarks")


    @api.depends('input_id.design_input_line_ids')
    def serial_number_datas(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.input_id.design_input_line_ids:
                no +=1
                line.s_no = no
    

            
            
            
    
     