from odoo import fields, models, api

class PlanInput(models.Model):
    _name = 'plan.input'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Plan Input" 

    name = fields.Char("Input")


class DesignInputPlan(models.Model):
    _name = 'design.input.plan'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Input" 

    name = fields.Char("Input")