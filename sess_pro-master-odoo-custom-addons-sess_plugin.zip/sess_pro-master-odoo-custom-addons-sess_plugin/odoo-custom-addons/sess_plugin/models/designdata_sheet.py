from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

  
class Designdatasheet(models.Model):
    _name = 'designdata.sheet'
    _rec_name="ref"
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Design Data Sheet"

    #form
    offer_no = fields.Char('No')
    offer_no_id = fields.Many2one('design.plan',string="Offer No",track_visibility='onchange',ondelete='cascade')
    offer_date=fields.Date(string="Offer Date",track_visibility='onchange')
    ref=fields.Char(string="REF",required=True,track_visibility='onchange')
    po_no=fields.Char(string="P.O.No",track_visibility='onchange')
    po_date=fields.Date(string="P.O.Date",track_visibility='onchange')
    machine_id = fields.Many2one('machine.master',string="Equipment Name",track_visibility='onchange')
    project_id=fields.Many2one('project.project',string="Project Name",track_visibility='onchange')
    partner_id=fields.Many2one('res.partner',string="Customer Name",track_visibility='onchange')
    email=fields.Char(string="Email",track_visibility='onchange')
    contact_no=fields.Char(string="Contact No",track_visibility='onchange')
    contact_person_id=fields.Many2one('res.partner',string="Contact Name",track_visibility='onchange')
    contact_person_name = fields.Char('Contact Person Name')
    project_detail=fields.Html(string="Project Details",track_visibility='onchange')
    drawing_id=fields.Many2many('ir.attachment',string="Concept Drawing/Model representation of the Equipment",track_visibility='onchange')
    status = fields.Selection([('draft','Draft'),('apprroved','Approved'),('reject','Reject')],string="Status",track_visibility='onchange',default = 'draft')
    
    
    #approval
    prepare_id=fields.Many2one('res.users',string="Prepared by:",track_visibility='onchange')
    prepare_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    prepare_date=fields.Date(string="Date",track_visibility='onchange')
    approved_id=fields.Many2one('res.users',string="Approved by:",track_visibility='onchange')
    approve_signature=fields.Binary(string="Signature", attachment=True,track_visibility='onchange')
    approve_date=fields.Date(string="Date",track_visibility='onchange')

    #inherit
    sale_id=fields.Many2one('sale.order',string="Sale Order",track_visibility='onchange')

    def action_approve(self):
        self.status = "apprroved"
    
    def action_reject(self):
        self.status = "reject"



            
            
            
    
     