from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Projectinherit(models.Model):
    _inherit="project.project"


    design_plan_count=fields.Integer(string="Design Plan Count",compute='plan_count')
    design_datasheet_count=fields.Integer(string="Design Data Sheet Count",compute='datasheet_count')
    design_input_count=fields.Integer(string="Design Input Count",compute='input_count')
    design_output_count=fields.Integer(string="Design Input Count",compute='output_count')
    design_review_count=fields.Integer(string="Design Review Count",compute='review_count')
    design_change_count=fields.Integer(string="Design Change Count",compute='change_count')
    design_verification_count=fields.Integer(string="Design Verification Count",compute='verification_count')
    design_validation_count=fields.Integer(string="Design Validation Count",compute='validation_count')
    drawing_attach_ids = fields.Many2many("ir.attachment",string="Drawing Attachment")
    plan_status = fields.Selection([('in_progress','In Progress'),('complete','Completed')],string="Status",default = 'in_progress')
    design_bom_count = fields.Integer('Design BOM Count',compute='bom_design_count')
    project_type = fields.Selection([('default_project','Default Project'),('machine_project','Machine Project')],string = 'Project Types',default = 'default_project')



   
    def plan_count(self):
        for rec in self:
            plan_orm=self.env['design.plan'].search([('project_id','=',rec.name)])
            self.design_plan_count = len(plan_orm) 

    def datasheet_count(self):
        for rec in self:
            datasheet_orm=self.env['designdata.sheet'].search([('project_id','=',rec.name)])
            self.design_datasheet_count = len(datasheet_orm)
    
    def input_count(self):
        for rec in self:
            input_orm=self.env['design.input'].search([('project_id','=',rec.name)])
            self.design_input_count = len(input_orm) 

    def output_count(self):
        for rec in self:
            output_orm=self.env['design.output'].search([('project_id','=',rec.name)])
            self.design_output_count = len(output_orm) 

    def review_count(self):
        for rec in self:
            review_orm=self.env['design.develop.review'].search([('project_id','=',rec.name)])
            self.design_review_count = len(review_orm)

    def change_count(self):
        for rec in self:
            change_orm=self.env['design.change.note'].search([('project_id','=',rec.name)])
            self.design_change_count = len(change_orm)

    def verification_count(self):
        for rec in self:
            verification_orm=self.env['design.verification'].search([('project_id','=',rec.name)])
            self.design_verification_count = len(verification_orm)

    def validation_count(self):
        for rec in self:
            validation_orm=self.env['design.validation'].search([('project_id','=',rec.name)])
            self.design_validation_count = len(validation_orm) 

    def bom_design_count(self):
        for rec in self:
            bom_design_orm=self.env['bom.master'].search([('project_id','=',rec.id)])
            self.design_bom_count = len(bom_design_orm)                                                  


    def get_plan_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Plan',
            'view_mode': 'tree,form',
            'res_model': 'design.plan',
            'domain': [('project_id', '=', self.id)],
            'context': {'default_project_id':self.id,
                    }
        }       

    def get_datasheet_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Data Sheet',
            'view_mode': 'tree,form',
            'res_model': 'designdata.sheet',
            'context': {'default_project_id':self.id,
                    }
        } 

    def get_input_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Input',
            'view_mode': 'tree,form',
            'res_model': 'design.input',
            'context': {'default_project_id':self.id,
                    }
        }  


    def get_output_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Output',
            'view_mode': 'tree,form',
            'res_model': 'design.output',
            'context': {'default_project_id':self.id,
                    }
        }     

    def get_review_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Development Review',
            'view_mode': 'tree,form',
            'res_model': 'design.develop.review',
            'context': {'default_project_id':self.id,
                    }
        }  

    def get_change_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Change Note',
            'view_mode': 'tree,form',
            'res_model': 'design.change.note',
            'context': {'default_project_id':self.id,
                    }
        }  

    def get_verification_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Verification',
            'view_mode': 'tree,form',
            'res_model': 'design.verification',
            'context': {'default_project_id':self.id,
                    }
        }   

    def get_validation_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design Validation',
            'view_mode': 'tree,form',
            'res_model': 'design.validation',
            'context': {'default_project_id':self.id,
                    }
        }            
    def design_bom_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Design BOM',
            'view_mode': 'tree,form',
            'res_model': 'bom.master',
            'context': {'default_project_id':self.id,
                        'default_bom_type':'design_bom',
                    }
        }         
        

    status_count = fields.Boolean("Status Count",compute="_count_status",store=True)
    
    @api.depends('plan_status')
    def _count_status(self):
        inprogress_count_orm=self.env['project.project'].search_count([('plan_status', '=', 'in_progress')])
        complete_count_orm=self.env['project.project'].search_count([('plan_status', '=', 'complete')])
        
        inprogres_kanban_master=self.env['master.kanban.view'].search([('name', '=', 'in_progress')],limit=1)
        inprogres_kanban_master.in_progress_count = inprogress_count_orm
        
        complete_kanban_master=self.env['master.kanban.view'].search([('name', '=', 'complete')],limit=1)
        complete_kanban_master.complete_count = complete_count_orm
        
        self.status_count = True
    
    
class KanbanMaster(models.Model):
    _name = "master.kanban.view"
    
    name = fields.Selection([('in_progress',"In Progress"),('complete',"Completed")],string="State")
    
    in_progress_count = fields.Integer("In Progress Count")
    complete_count = fields.Integer("Complete")
    
    

    
    
    def in_progress_data(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Projects',
            'view_mode': 'tree,form',
            'res_model': 'project.project',
            'domain': [('plan_status', '=', 'in_progress'),('project_type','=','default_project')],
        }     
        
    
    def complete_project(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Projects',
            'view_mode': 'tree,form',
            'res_model': 'project.project',
            'domain': [('plan_status', '=', 'complete'),('project_type','=','default_project')],
        }   
        