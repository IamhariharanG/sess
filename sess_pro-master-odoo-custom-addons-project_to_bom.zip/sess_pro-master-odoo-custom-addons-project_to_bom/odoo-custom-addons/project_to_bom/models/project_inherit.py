from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Projectinherit(models.Model):
    _inherit="project.project"


    bom_count=fields.Integer(string="Bom Count",compute='bom_counts')

    def bom_counts(self):
        for rec in self:
            bom_orm=self.env['bom.master'].search([('project_id','=',rec.id),('bom_type','=','request')])
            self.bom_count = len(bom_orm) 

    def get_bom_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Request Bom',
            'view_mode': 'tree,form',
            'res_model': 'bom.master',
            'domain': [('project_id', '=', self.id)],
            'context': "{'create': False}"
        }          
   