from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Bominherit(models.Model):
    _inherit="mrp.bom"

    project_id=fields.Many2one('project.project',string="Project Name")
    item_category_id = fields.Many2one('department.master',string = 'Item Category',tracking= True )
    total = fields.Monetary('Total',compute='_compute_amount',store=True)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                 related='company_id.currency_id',
                                 default=lambda
                                 self: self.env.user.company_id.currency_id.id)
    @api.depends('bom_line_ids')
    def _compute_amount(self):
        for rec in self:
           
            rec.total = sum(rec.bom_line_ids.mapped('tax_amount')) + sum(rec.bom_line_ids.mapped('sub_total'))
    

    # @api.onchange('project_id')
    # def compute_bom(self):
    #     for rec in self:
    #         if rec.project_id:
    #             orm = self.env['purchase.request'].search([('project_id','=',rec.project_id.id),('purchase_order_id','!=',False)])
    #             if orm:
    #                 line_data=[(5,0,0)]
    #                 for datas in orm:
    #                     if datas:
    #                         for ids in datas.purchase_order_id:
    #                             for line in ids.order_line:
    #                                 data = {'product_id':line.product_id.id,
    #                                         'product_qty':line.product_qty,
    #                                         'make':line.make,
    #                                         'model_no':line.model_no,
    #                                         'sl_no':line.sl_no,
    #                                         'unit_price':line.price_unit,
    #                                         'taxes_ids': [( 6, 0, [line.taxes_id.id])],
    #                                         'sub_total':line.price_subtotal}
    #                                 line_data.append((0,0,data))            
    #                 self.bom_line_ids = line_data
    #             else:
    #                 pass
    #         else:
    #             pass


class bom_line_inherit(models.Model):
    _inherit  = 'mrp.bom.line'

    make = fields.Char('Make')
    model_no = fields.Char('Model Number')
    sl_no = fields.Char('SL.NO') 
    taxes_ids = fields.Many2many('account.tax',string='Taxes')
    unit_price = fields.Float('Unit Price')
    sub_total = fields.Monetary('SubTotal',compute= 'compute_sub_total',store = True)
    tax_amount = fields.Monetary('Tax Amount',compute = 'tax_calculation',store=True)

    currency_id = fields.Many2one('res.currency', string="Currency",
                                 related='company_id.currency_id',
                                 default=lambda
                                 self: self.env.user.company_id.currency_id.id)

    @api.depends('unit_price','product_qty')
    def compute_sub_total(self):
        for rec in self:
            if rec.unit_price and rec.product_qty:
                rec.sub_total= rec.unit_price * rec.product_qty
    
    @api.depends('taxes_ids','sub_total')  
    def tax_calculation(self):
        for l in self:
            if l.taxes_ids:
                k= (l.taxes_ids[0].name)
                if k:   
                    if k[-3]!='':
                        o = int(k[-3]+k[-2])
                        l.tax_amount = l.sub_total * (o /100)
                        
                    elif  int(k[-2]):
                        l.tax_amount = l.sub_total *(int(k[-2])/100)
                       
                    else:
                        pass
                else:
                    pass