{
    'name': 'Project to Manufacturing Bom',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Project to Manufacturing Bom',
    'depends': ['base','sale','purchase','sess_inherit'],
    'data': [
          'security/ir.model.access.csv',
          'views/bom_inherit.xml',
          'views/project_inherit.xml',
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
