

// odoo.define('sess_portal.custom_script', function (require) {
//     "use strict";

//     var core = require('web.core');
//     var ajax = require('web.ajax');

//     $(document).ready(function () {
//         // Your JavaScript code here
//         // For example, handle button click

//         $('.my-button').on('click', function () {
//             // Do something when the button is clicked
//             alert('Button Clicked');
//         });
//     });
// });

// alert("vcjsvbc");
odoo.define('sess_portal.generic_form', function(require){
	"use strict";

	var publicWidget = require('web.public.widget');
	var core = require('web.core');
	var ajax = require('web.ajax');
	var rpc = require('web.rpc');
	var core = require('web.core');
	var QWeb = core.qweb;
	var _t = core._t;

	publicWidget.registry.generic_form_data = publicWidget.Widget.extend({
    	selector: '#feedback_form',
    	events: {
       	'click .add_total_project': '_onClickAdd_total_project',
       	'click .remove_line': '_onClickRemove_line',
       	'click .custom_create': '_onClickSubmit',
   	},
       

   	_onClickSubmit: async function(ev){
            
        	var self = this;
        	var cost_data = [];
        	var rows = $('table.total_project_costs > tbody > tr.project_cost_line');
        	_.each(rows, function(row) {
            	let machine_name = $(row).find('select[name="machine_name"]').val();
            	let model_no = $(row).find('input[name="model_no"]').val();
            	let serial_no = $(row).find('input[name="serial_no"]').val();
            	console.log(model_no, serial_no)
            	cost_data.push({
                	'machine_id': machine_name,
                	'machine_model_no': model_no,
                	'machine_sl_no': serial_no,
            	});
        	});
        	$('textarea[name="data_line_ids"]').val(JSON.stringify(cost_data));

   	},
// To Remove Line 
   	_onClickRemove_line: function(ev){
                    
					var row = $(ev.target).closest('tr');
					row.remove();

    	},
       

   	_onClickAdd_total_project: function(ev){
                console.log('hai')
            	var $new_row = $('.add_extra_project').clone(true);
            	$new_row.removeClass('d-none');
            	$new_row.removeClass('add_extra_project');
            	$new_row.addClass('project_cost_line');
            	$new_row.insertBefore($('.add_extra_project'));
            	_.each($new_row.find('td'), function(val) {
                	$(val).find('input').attr('required', 'required'); //based On Input Attr given in xml
                	$(val).find('select').attr('required', 'required'); //based On Select   Attr given in xml


            	});
        	},

	});
});