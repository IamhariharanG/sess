{
    'name': 'Odoo Vendor Portal',
    'version': '14.0.1.0.0',
   
    'description': """Customer Complaints Management in Odoo""",
 
    'depends': ['website', 'portal'],
    'data': ['views/login_form.xml',
       
    ],
   
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
