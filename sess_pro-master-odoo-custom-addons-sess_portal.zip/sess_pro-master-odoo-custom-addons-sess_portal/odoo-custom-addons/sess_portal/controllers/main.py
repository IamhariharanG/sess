from odoo import http
from odoo.addons.website.controllers.main import Website
from odoo.addons.portal.controllers.web import Home
from odoo.http import request
from odoo.exceptions import ValidationError
import base64
import json




class CustomerPoratl(http.Controller):
    @http.route('/page/complaints',type="http",auth="public",website=True)
    def handle_redirection_page(self,**kw):
        product_main_can = request.env['machine.master'].sudo().search([])
        
        return http.request.render('sess_portal.direct_redirection',{'product_main_can':product_main_can})
    
  


    @http.route('/submit/data',type="http",auth="public",website=True)
    def create_complaints_data(self,**kw):
        machine_name =  request.httprequest.form.getlist('product_main')
        expected_date = kw.get('date_name','')
        notes = kw.get('notes','')
        request.session['machine_name'] = machine_name
        request.session['expected_date'] = expected_date
        request.session['notes'] = notes
        values = {
            'expected_date' : expected_date,
            'complaint_description' : notes,
            'partner_id': http.request.env.user.partner_id.id,
            'mode_of_complaint':'portal',
            'email_id':http.request.env.user.login,
        }
        create =request.env['customer.register'].sudo().create(values)
        l=[]
        for id in machine_name:
            l.append((0, 0, {
            'line_id':create.id,
            'machine_id': int(id)}))
        create.machine_line_id = l
        return request.render('sess_portal.thank_you',{'data':'complaint'})
    

    @http.route('/page/feedback',type="http",auth="public",website=True)
    def handle_redirection(self,**kw):
        partner_name = request.env['res.partner'].sudo().search([])
        machine_name = request.env['machine.master'].sudo().search([])
        return http.request.render('sess_portal.feedback_form',{'partner_name':partner_name,
                                                                'all_machines':machine_name,})
        
    
    @http.route('/submit/feedback',type="http",auth="public",website=True)
    def create_complaints(self,**kw):
        partner_name = kw.get('partner_name','')
        name = kw.get('name','')
        department = kw.get('department','')
        contact_no = kw.get('contact_no','')
        period = kw.get('period','')
        year = kw.get('year','')
        sess_product = kw.get('sess_product','')
        type_of_feedback = kw.get('type_of_feedback','')
        criteria_spec = kw.get('criteria_spec','')
        criteria_delivery = kw.get('criteria_delivery','')
        criteria_attend_complaints = kw.get('criteria_attend_complaints','')
        criteria_timely_response = kw.get('criteria_timely_response','')
        criteria_improvements = kw.get('criteria_improvements','')
        customer_remarks = kw.get('customer_remarks','')
        request.session['partner_name'] = partner_name
        request.session['name'] = name
        request.session['department'] = department
        request.session['contact_no'] = contact_no
        request.session['period'] = period
        request.session['year'] = year
        request.session['sess_product'] = sess_product
        request.session['type_of_feedback'] = type_of_feedback
        request.session['criteria_spec'] = criteria_spec
        request.session['criteria_delivery'] = criteria_delivery
        request.session['criteria_attend_complaints'] = criteria_attend_complaints
        request.session['criteria_timely_response'] = criteria_timely_response
        request.session['criteria_improvements'] = criteria_improvements
        request.session['customer_remarks'] = customer_remarks

        values = {
            'partner_id' : partner_name,
            'customer_contact_person': name,
            'department' : department,
            'contact_no' : contact_no,
            'period' : period,
            'supplied_year' : year,
            'sess_product' : sess_product,
            'type_of_feedback' : type_of_feedback,
            'criteria_spec' : criteria_spec,
            'criteria_delivery' : criteria_delivery,
            'criteria_attend_complaints' : criteria_attend_complaints,
            'criteria_timely_response' : criteria_timely_response,
            'criteria_improvements' : criteria_improvements,
            'customer_remarks':customer_remarks,
        }

        create =request.env['customer.feedback'].sudo().create(values)
        data = json.loads(kw['data_line_ids'])
        val = [ (0,0,line) for line in data]
        create.machine_lines_id = val
        return request.render('sess_portal.thank_you',{'data':'feedback'})