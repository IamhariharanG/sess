from odoo import fields, models, api, _
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF
class purchase_request_form(models.Model):
    _name = 'purchase.request'
    _rec_name = 'name'
    _order =  'id desc'
    _description = "Request Form"
    _inherit = ['mail.thread','mail.activity.mixin'] 
    
    partner_id =fields.Many2one('res.partner',string="Internal Engineer",default=lambda self: self.env.user.partner_id.id,domain=[('internal_engineer','=','internal')],required =True) 
    purchase_request_ids = fields.One2many('purchase.request.line','line_id',string="Purchase Request Form",required = True)
    project_id  = fields.Many2one('project.project',string = 'Project Name',tracking= True)
    validity_date = fields.Datetime(string="Validity Date",tracking= True)
    delivery_date = fields.Datetime(string="Delivery Date",tracking= True)
    loc_id = fields.Many2one('stock.location',string = 'Delivery Location')
    purchase_order_id = fields.Many2one('purchase.order',string = 'Purchase Order')
    customer_id = fields.Many2one('res.partner',domain=[('child_ids','!=',False)],string= 'Customer Name')
    supplier_ids = fields.Many2many('res.partner',string="Suggested Supplier",required = True,domain=[('supplier_rank','=',1)])#domain=[('internal_engineer','=','supplier')],
    create_val = fields.Boolean('Create value')
    state = fields.Selection([('unforward','Unforwarded'),('forward', 'Forwarded'),('complete','Completed')],string = 'Status',default = 'unforward',tracking= True)
    item_category_id = fields.Many2one('department.master',string = 'Item Category',tracking= True )
    purpose = fields.Selection([('under_amc','Under AMC'),('under_cmc','Under CMC'),('out_of_warrenty','Out Of Warrenty'),('under_warrenty','Under Warrenty'),('factory_production_work','Factory Production Work')],string = 'Purpose Of Purchase')
    designation_id =fields.Many2one('hr.department',string = 'Designation')
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,  default=lambda self: self.env.company.id)
    name = fields.Char('Name',tracking= True)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                 related='company_id.currency_id',
                                 default=lambda
                                 self: self.env.user.company_id.currency_id.id)
    purchase_total = fields.Float('Purchase Amount')

    # @api.onchange('validity_date')
    # def _check_date(self):
    #     if self.validity_date and self.validity_date < datetime.now():
    #         self.validity_date = False
    #         return {
    #             'warning': {'title': _('Invalid Date'),
    #                         'message': _("Please Give Valid Date"), },
    #         }       
    
    @api.model
    def create(self,vals):
        result = super(purchase_request_form, self).create(vals)
        result.name = f"IPRF{self.env['ir.sequence'].next_by_code('sequence.purchase.request')}"
        return result
    
    
    
    def purchase_request(self): 
        if (self.supplier_ids):
            
            for val in self.supplier_ids:  
                if self.create_val == True:
                    raise ValidationError('You Have Already Forwarded The Purchase Form')
                    
                else:
                    self.state = 'forward'
                    if self.purchase_request_ids:#'date_order' : self.validity_date,
                        orm = self.env['purchase.order'].create({
                                                            'internal_engg_id'  :self.partner_id.id,
                                                            'purchase_request_id': self.id,
                                                            'request_ref': self.name,
                                                            'partner_id' : val.id,
                                                            'l10n_in_gst_treatment' : 'consumer',
                                                                    }) 
                    
                        
                        for each in self.purchase_request_ids:

                                
                            orm_line = self.env['purchase.order.line'].create({ 'order_id'  : orm.id,
                                                                            'product_id' : each.product_id.id,
                                                                            'product_uom': each.product_uom.id,
                                                                        'product_qty' : each.qty,
                                                                        'model_no' :each.model_no,
                                                                        'make':each.make,
                                                                        'sl_no':each.sl_no,
                                                                        'price_unit' :each.price_unit,}) 
                    else: 
                        raise ValidationError('Please Enter The Products and the Quantities') 
        else:
            pass       
        self.create_val = True
                



class ParticularReport(models.AbstractModel):
    _name = 'report.sess_inherit.report_request_quotation'

    @api.model  
    def render_html(self, docids, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('sess_inherit.report_request_quotation')
        docargs = {
            'doc_ids': docids,
            'doc_model': report.model,
            'docs': self,
        }
        return report_obj.render('sess_inherit.report_request_quotation', docargs)        


   

class purchase_request_line(models.Model):
    _name = 'purchase.request.line'
    
    line_id = fields.Many2one('purchase.request',string ='lines')
    product_id = fields.Many2one('product.product',string = 'Item Code')
    product_name = fields.Char(related ='product_id.name',string = 'Description Of Items')
    size = fields.Integer(related = 'product_id.pack_size',string = 'Size')
    hsn_code = fields.Char('HSN Code',related = 'product_id.l10n_in_hsn_code',readonly = False)
    qty = fields.Float('Quantity')

    product_uom = fields.Many2one('uom.uom', string = 'UoM',related = 'product_id.uom_id',readonly = False)
    product_qty = fields.Float('PO Quantity')
    price_unit = fields.Float('PO Unit Price')
    make = fields.Char('Make')
    model_no = fields.Char('Model No')
    sl_no = fields.Char('SL.NO',) 
    company_id = fields.Many2one('res.company', store=True, copy=False,
                                string="Company",
                                default=lambda self: self.env.user.company_id.id,readonly = True)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                 related='company_id.currency_id',
                                 default=lambda
                                 self: self.env.user.company_id.currency_id.id)                