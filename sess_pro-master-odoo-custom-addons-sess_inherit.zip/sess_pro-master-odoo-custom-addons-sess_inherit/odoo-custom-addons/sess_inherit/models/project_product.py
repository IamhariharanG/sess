from odoo import fields, models, api, _
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF



class project_product(models.Model):
    _name = 'project.product'
   
   
    
    product_id =fields.Many2one('product.product',string="Product",) 
    product_qty = fields.Float('Quantity')
    size = fields.Integer('Size',)
    unit_id =  fields.Many2one('uom.uom',related = 'product_id.uom_id')
    remain_qty = fields.Float('Remain Qty',compute= 'onchange_product_qty',store=True)
    project_id  = fields.Many2one('project.project',string = 'Project Name',)
    
    
    @api.onchange('product_qty',)
    def onchange_product_qty(self):
        for each in self:
            if each.product_qty:
                location = self.env['stock.location'].search([('complete_name', '=', 'WH/Input')])#  'WH/Stock'
                quant = self.env['stock.quant'].search([('product_id', '=', each.product_id.id), ('location_id', '=', location.id)])
                if quant.available_quantity > each.product_qty:
                    quant.write({'quantity': quant.quantity - each.product_qty})
                elif quant.available_quantity < each.product_qty and quant.available_quantity !=0:
                    raise ValidationError(f"The Available Product Quantity In The Stock is  {quant.available_quantity}. You Have To Give Lesser Then {quant.available_quantity} To  Use In Projects")
                elif quant.available_quantity == 0:
                    raise ValidationError(f'There Is  No Available Quantity In The Stock')
                else:
                    pass
                   
            else:
                pass
    
    # @api.onchange('product_qty')
    # def onchange_product_qty(self):
    #     for each in self:
            # val= each.product_qty
           
                # data = self.env['product.product'].search([('id', '=', each.product_id.id)])
                # val = each.product_qty
                # avail = data.qty_available 
                # data.write({'qty_available':  avail - val})
                
                # each.remain_qty = data.qty_available
                # raise ValidationError(data.name)
            # for line in each:
            #     # raise ValidationError(line.product_qty)
                
            #     if line.product_qty:
            #         location = self.env['stock.location'].search([('name', '=', 'Input')])
            #         quant = self.env['stock.quant'].search([('product_id', '=', line.product_id.id), ('location_id', '=', location[-1].id)])
            #         val =  quant.available_quantity - line.product_qty
            #         quant.write({'available_quantity':100})
            #         self.remain_qty = line.product_qty
            #     else:
            #         raise ValidationError('h')
            
            
    # @api.onchange('project_id.project_line_id')
    # def onchange_qty(self):
    #     for each in self:
    #         if each.product_qty:
    #             data = self.env['product.product'].search([('id', '=', each.product_id.id)])
    #             val = each.product_qty 
    #             raise ValidationError(data.qty_available)
                
    #             avail = data.qty_available 
    #             data.qty_available = avail - val