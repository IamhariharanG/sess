from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Rating_form(models.Model):
    _name = 'rating.form'
    _rec_name = 'partner_id'
    _description = "Rating Form"
    _inherit = ['mail.thread','mail.activity.mixin'] 
    
    department = fields.Many2one(comodel_name='department.master',string="Product & Department",compute = 'compute_bill_date',store = True)
    partner_id = fields.Many2one('res.partner',string= 'Vendor Name',compute = 'compute_bill_date',store = True)
    bill_no  =  fields.Char('Purchase Bill Number',)
    po_number = fields.Many2one('purchase.order',string = 'Purchase Bill No', )
    bill_date = fields.Datetime(string="Bill Date",compute = 'compute_bill_date',store = True)
    received_qty = fields.Char('Received Quantity(In Numbers)',compute = 'compute_bill_date',store = True)
    accepted_qty = fields.Char('Accepted Quantity(In %)',)
    credit_limit_provider = fields.Selection([('po_with_advance','PO With Some Advance'),('against_despatch','Against Despatch'),('30_days_credit','30 Days Credit'),
                                              ('45_days_credit','45 Days Credit'),('60_days_credit','60 Days Credit'),('90_days_credit','90 Days Credit'),
                                              ('on_date_check','On Date Check')],string ='Credit Limit Provider')
    material_quality_rating = fields.Selection([('100%','Excellent(100%)'),('80%','Good(80%)'),('60%','Not Bad(60%)'),('50%','Bad(below 50%)')],string ='Material Quality Rating')
    material_delivery_time = fields.Selection([('100%','Excellent(100%)'),('80%','Good(80%)'),('60%','Not Bad(60%)'),('50%','Bad(below 50%)')],string ='Material Delivery Time')
    technical_support = fields.Selection([('100%','Excellent(100%)'),('80%','Good(80%)'),('60%','Not Bad(60%)'),('50%','Bad(below 50%)'),('na','N/A')],string ='Technical Support')
    warrenty_replace_support = fields.Selection([('80%','Good(80%)'),('60%','Not Bad(60%)'),('50%','Bad(below 50%)'),('na','N/A')],string ='Warrenty Replace Support')
                                             
                                             
    @api.depends('po_number')
    def compute_bill_date(self):
        for each in self:
            
            if each.po_number:
                vals_new=self.env['stock.picking'].search([('origin','=',each.po_number.name)])
                self.partner_id = vals_new.partner_id.id
                self.bill_date = vals_new.invoice_date
                self.department = vals_new.department_id.id
            
                if (vals_new.move_ids_without_package):
                    self.received_qty = str(sum(vals_new.move_ids_without_package.mapped('quantity_done'))) 
                else:
                    pass
            else:
                pass
        
        
class ackowledgement_data(models.Model):

    _name = 'acknowledgement.check'
    _rec_name = 'detail'


    checking_date = fields.Datetime(string='Date',default=(datetime.now()))
    detail = fields.Char(string='Detail')
    order_acknowledge = fields.Many2one('sale.order',string='Sale')

