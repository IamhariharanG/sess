from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Sessproductitems(models.Model):
    _inherit = 'product.template'
    
    department=fields.Many2one(comodel_name='department.master',string="Department")
    pack_size=fields.Integer(string="Pack Size")
    qty_packsize=fields.Integer(string="Quantity Of Pack")
    
  
    
    

  

