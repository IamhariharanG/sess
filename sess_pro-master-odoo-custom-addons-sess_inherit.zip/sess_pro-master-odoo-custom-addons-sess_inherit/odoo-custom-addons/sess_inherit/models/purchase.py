from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError
from num2words import num2words
import dateutil.parser
from dateutil.relativedelta import relativedelta

class Sessproductitems(models.Model):
    _inherit = 'purchase.order'
    _rec_name = 'name'
    
    attachment = fields.Binary(string="Signature")
    payment_term = fields.Selection([('cash','Cash'),('cheque', 'Cheque'),('ptc', 'PDC'),('neft','NEFT'),('credit','Credit'),('gpay/phonepay','Gpay/Phone Pay')],'Payment Term',default="cash",tracking= True)
    internal_engg_id = fields.Many2one('res.partner',string="Internal Engineer",domain="[('internal_engineer', '=', True)]")
    tot = fields.Integer('Total',compute ='compute_total_qtys',store = True)
    date_pdf = fields.Char('Date Planned',store = True,compute ='compute_date')
    purchase_request_id  = fields.Many2one('purchase.request',string = 'Purchase Request')
    num_to_word = fields.Char('Total In Words',compute = '_compute_amount_in_word',store = True)
    round_off = fields.Float(string="Round Off", compute='_compute_amount_in_word',store = True)
    department_id =fields.Many2one(comodel_name='department.master',string="Department")
    purchased_by = fields.Many2one('res.partner',string="Purchased/Handovered By",tracking= True)
    terms_conditions = fields.Html('Terms And Conditions')
    rfq_name =fields.Char('Rfq No',tracking= True)
    terms_conditions_id = fields.Many2one('terms.conditions',"Terms and Conditions")
    request_ref = fields.Char('Request Reference')
    grand_total = fields.Monetary(string="Round Off Total",compute = 'compute_grand_total',store = True )
    invoice_bill_no = fields.Char('Invoice Bill No')
    invoice_date = fields.Datetime('Invoice Date')
   
    

    @api.depends('amount_total')
    def compute_grand_total(self):
        for order in self:
            order.grand_total = round(order.amount_total)

   
    def purchase_order_report(self):
        return self.env.ref('sess_inherit.report_purchase_pdf').report_action(self)

    # @api.onchange('partner_id')
    # def po_tax(self):
    #     record = self.env['product.product'].search([('company_id','=',2)])
    #     taxes_company_2_id = [92]
    #     for each in record:
    #         each.write({'supplier_taxes_id': [( 6, 0, taxes_company_2_id)]})
           

    @api.constrains('state')
    def sample_rec(self):

        if self.state== 'draft' or self.state == 'sent':
            self.name = f"RFQ{self.env['ir.sequence'].next_by_code('sequence.purchase.rfq')}"
            self.rfq_name =  self.name
        elif self.state== 'purchase':
            self.name = f"P00{self.env['ir.sequence'].next_by_code('sequence.purchase')}"

    
    @api.onchange('terms_conditions_id')
    def _termscondition(self):
        for rec in self:
            rec.terms_conditions = rec.terms_conditions_id.terms
    
    @api.depends('amount_total')
    def _compute_amount_in_word(self):
        for rec in self:
            rec.round_off = round(rec.amount_total)
            rec.num_to_word ='Rupees '+ str(num2words(rec.round_off,lang='en_IN')).title()+ ' Only'   
            
           
            
    def write(self, values):
        val =  super(Sessproductitems, self).write(values)
        if self.state =='purchase':
            purchase_inventory=self.env['stock.picking'].search([('origin','=',self.name)])
            
            purchase_inventory.write({'tot_amt':self.amount_total})
            orm_id = self.env['purchase.request'].search([('id','=',self.purchase_request_id.id)])
            orm = self.env['purchase.order'].search([('purchase_request_id','=',orm_id.id)])
            line = self.env['purchase.request.line'].search([('line_id','=',orm_id.id)])
            for each in orm:
                if  each.state == 'purchase':   
                   if orm_id: 
                        data = orm_id.write({'purchase_order_id':each.id,
                                  'state':'complete',
                                   'purchase_total': each.round_off, }) 
                        l = []
                        j = []
                        for each_id in self.order_line:

                            l.append(each_id.product_qty)   
                            j.append(each_id.price_unit)    
                        for i in range(len(line)):
                            if  j[i]>0:
                                line[i].product_qty = l[i]
                                line[i].price_unit = j[i]    
                            else:
                                raise ValidationError('Enter Unit Price for All  Products')
                   else:
                       pass
                else:
                    pass #each.state = 'cancel'
        else:
            pass
        return val
    
    
    @api.depends('order_line')
    def compute_total_qtys(self):
        qty = []
        for i in self:
            for k in i.order_line:
                
                qty.append(int(k.product_qty))
        i.tot  = sum(qty)
        
    # @api.onchange('order_line')
    # def _tax_for_products(self):
    #     for line in self:

    #         for l in line.order_line:
    #             if l.taxes_id:
    #                 k= (l.taxes_id[0].name)
    #                 if k:   l
    #                     if k[-3]!='':
    #                         o = int(k[-3]+k[-2])
    #                         line.amount_tax = l.price_subtotal * (o /100)
    #                         raise ValidationError(line.amount_tax)
    #                     elif  int(k[-2]):
    #                         line.amount_tax = l.price_subtotal *(int(k[-2])/100)
    #                         # raise ValidationError(line.amount_tax)
    #                     else:
    #                         pass
    #                 else:
    #                     pass

    #             else:
    #                 pass   
        
    @api.depends('date_order')
    def compute_date(self):
        for rec in self:
            for each in rec:
                if each.date_order:
                    self.date_pdf = str(each.date_order.date().strftime("%d-%b-%Y"))
                
class sale_order_inherit(models.Model):
    _inherit = 'sale.order'
    
    project_id  = fields.Many2one('project.project',string = 'Project Name')
    department_id = fields.Many2one('department.master',string = 'Department',states={'done': [('readonly', True)]})
    model_no = fields.Char('Model Number',states={'done': [('readonly', True)]})
    serial_no = fields.Char('Serial Number',states={'done': [('readonly', True)]})
    date_pdf = fields.Char('Date Planned',compute = 'compute_date',store = True)
    task_or_manufac = fields.Selection([('internal_project','Internal Project'),('manufacturing_order','Manufacturing Order')],string = 'Select Order', states={'done': [('readonly', True)]})
    create_bool = fields.Selection([('sale','Sale'),('draft','Quotation'),('sent','Send'),('done','Done'),('cancel','Cancel')],compute = 'onchange_bool',string = 'Create',)
    partner_id = fields.Many2one('res.partner',domain="[('internal_engineer', '=', False),('child_ids','!=',False)]")
    purchased_by = fields.Many2one('res.partner',string="Purchased/Handovered By",)
    upload_file = fields.Many2many('ir.attachment',string='Upload Attachment',attachment=True)
    file_name = fields.Char("File Name")
    order_acknowledge = fields.Selection([('order_acknowledgement','Order Acknowledgement'),('complete','Completed')],string = 'For Acknowledge', )
    acknowledgement=fields.One2many('acknowledgement.check','order_acknowledge',string='Acnowledgement')
    offer_stage = fields.Selection([('10','10%'),('20','20%'),('30','30%'),('40','40%'),('50','50%'),('60','60%'),('70','70%'),('80','80%'),('90','90%'),('100','100%')],string = 'Offer Letter Stage',tracking= True )
    terms_conditions = fields.Html('Terms And Conditions')
    offer_required = fields.Char('Offer Required')
    procure_plan = fields.Char('Procurement Duration Plan')
    budget_cost = fields.Char('Budget Cost')
    temp_min = fields.Char('Temperature In Cooling Min Range')
    temp_max = fields.Char('Temperature In Cooling Max Range')
    humidity = fields.Char('Humidity Range')
    co_2_range = fields.Char('Co2 Range')
    humidity_climatic = fields.Char('Humidity Climatic Range')
    test_speciman = fields.Char('Test Specimen detail')
    pc_software = fields.Char('PC Software')
    chamber_inner_air = fields.Char('Chamber inner Air circulation controlling device (Drive) (Y/N)')
    speciman_loading_tray = fields.Char('Specimen Loading Tray our Standard with chamber One number (Please specify the QTY if additional trays are required) at extra cost')
    expected_date = fields.Char('Expected Date of Delivery')
    contact_sale_person = fields.Char('Contacted Sales Person Name')
    view_window = fields.Char('Viewing Window - Optional (Y/N)')
    request_id = fields.Many2one('purchase.request',string = 'Request Number')


    
    approval_state = fields.Selection([('internal_customer_po','Internal Customer Po Approval'),
                                       ('customer_po_request_forward','Customer Po Request Note Forward To Customer'),
                                       ('po_internal_final_approval','PO Internal Final Approval')],string = 'Approval State', )
    
    project_create_bool = fields.Boolean('Project Bool')
    terms_conditions_id = fields.Many2one('terms.conditions',"Terms and Conditions")
    sale_type=fields.Selection([('spare_sale','Spare Sale'),('product_sale','Product sale')],string = 'Sale Type',readonly= True)
    
    grand_total = fields.Monetary(string="Round Off Total",compute = 'compute_grand_total',store = True )
   
   
    # @api.onchange('department_id')
    # def sale_tax(self):
    #     record = self.env['product.product'].search([])
        
    #     taxes_id = [74]

    #     for each in record:
            
    #         each.write({'taxes_id': [( 6, 0, taxes_id)]})
    # @api.onchange('partner_id')
    # def po_tax(self):
    #     record = self.env['product.product'].search([])
    #     taxes_company_1_id = [74]
    #     taxes_company_2_id = [94]

    #     for each in record:
    #         if each.company_id == 1:
    #             each.write({'taxes_id': [( 6, 0, taxes_company_1_id)]})
    #         elif each.company_id == 2:
    #             each.write({'taxes_id': [( 6, 0, taxes_company_2_id)]})
    #         else:
    #             pass        

    @api.depends('amount_total')
    def compute_grand_total(self):
        for order in self:
            order.grand_total = round(order.amount_total)

    @api.onchange('request_id')
    def onchange_request_id(self):
        for rec in self:
            line_data = [(5,0,0)]
            orm_id = self.env['purchase.request'].search([('id','=',rec.request_id.id)])
            for each in orm_id.purchase_request_ids:
                data ={
                    'order_id':self._origin.id,
                    'product_id':each.product_id.id,
                    'name' :each.product_id.name,
                    'product_uom_qty':each.qty,
                    'price_unit':each.price_unit,
                    'product_uom':each.product_uom.id,
                }
                line_data.append((0,0,data))
        self.order_line = line_data
               


    # def sale_order_report(self):
    #     return self.env.ref('sess_inherit.report_sale_pdf').report_action(self)
    # def sale_order_request_report(self):
    #     return self.env.ref('sess_inherit.report_sale_quotation_pdf').report_action(self)

    @api.onchange('terms_conditions_id')
    def _termscondition(self):
        for rec in self:
            rec.terms_conditions = rec.terms_conditions_id.terms
    
    @api.depends('date_order')
    def compute_date(self):
        for rec in self:
            for each in rec:
                if each.date_order:

                    self.date_pdf = str(each.date_order.date().strftime("%d-%b-%Y"))
                    
    @api.onchange('offer_stage')
    def compute_order_acknowledge(self):
        if self.offer_stage:
            if self.offer_stage == '100':
                self.order_acknowledge  = 'complete'
                 
            else:
                self.order_acknowledge ='order_acknowledgement'
    @api.onchange('state')
    def action_confirms(self):
        if self.state == 'draft' or self.state =='sent':
            if self.order_acknowledge and self.offer_stage:
                if self.offer_stage != '100' or self.order_acknowledge == 'order_acknowledgement':
                    raise ValidationError('Please Change The Offer stage To 100% And Then Confirm Sale Order')
                else:
                    pass
        
    
    @api.depends('create_bool')
    def onchange_bool(self):
        if self.state :
            self.create_bool = self.state
            for each in self:
                if each.task_or_manufac == 'internal_project' and each.create_bool =='sale' and  not self.project_create_bool:
                    
                    create =  self.env['project.project'].create({'name':each.name,
                                                                  'sale_id':each.id})

                    # create = self.env['project.task'].create({'name':each.name,
                    #                                     'project_id':each.project_id.id,
                    #                                     'partner_id':each.partner_id.id,
                    #                                     'sale_id':each.id,})
                    # self.state = 'done'
                    self.project_create_bool = True
                elif each.task_or_manufac =='manufacturing_order' and each.create_bool =='sale' and not self.project_create_bool:
                    for line in each.order_line:
                        create = self.env['mrp.production'].create({'product_id':line.product_id.id,
                                                           'product_uom_id':line.product_uom.id,
                                                           'sale_id':each.id,}) 
                    # self.state = 'done'
                    self.project_create_bool = True

                else:
                    pass
                
class Projectproject_inherit(models.Model):
    _inherit ='project.project'   

    
    sale_id = fields.Many2one('sale.order',string = 'Sale Reference')
    project_line_id  = fields.One2many('project.product','project_id',string="Product Lines",)
    request_count = fields.Integer('Requests',compute = 'compute_total_request',)
    
    
   
    
    
    
    
    def create_request_line(self):
        return {'name': ('Internal Purchase Request Form'),
                      'type': 'ir.actions.act_window',
                      'res_model': 'purchase.request',
                      'view_mode': 'tree,form',
                      'domain': [('project_id', '=', self.id),],
                      'context': "{'create': False}",
                      
                     }
        
    def compute_total_request(self):
            
        for each in self:
                each.request_count = self.env['purchase.request'].search_count([('project_id', '=', self.id),])
    
    def create_request(self):
        for rec in self:
            create = self.env['purchase.request'].create({'project_id':self.id,
                                                        #    'product_uom_id':line.product_uom.id,
                                                           }) 
            # create.
            
            for each in self.project_line_id:

                                
                orm_line = self.env['purchase.request.line'].create({ 'line_id'  : create.id,
                                                                            'product_id' : each.product_id.id,
                                                                            'product_uom': each.unit_id.id,
                                                                            'size' : each.size,
                                                                        'qty' : each.product_qty,
                                                                        'price_unit' :0.0,}) 
                
                
        
        
class  stock_picking_inherit(models.Model):
    _inherit = 'stock.picking'

    delivery_types = fields.Selection([('returnable','Returnable'),('non_returnable','Non Returnable')],string='Delivery Type', states={'done': [('readonly', True)]})
    non_ret_dcs = fields.Selection([('warrenty','Warrenty'),('po_against','PO Against'),('free_of_cost','Free Of Cost')],string='Non-Return DC',default="warrenty", states={'done': [('readonly', True)]})
    person_name = fields.Char('Person Name/Mode of Delivery',states={'done': [('readonly', True)]})
    scrap = fields.Many2one('stock.scrap','Scrap', states={'done': [('readonly', True)]})  
    purpose = fields.Char('Purpose',states={'done': [('readonly', True)]}) 
    tot_amt = fields.Float('Total Price',compute=  'compute_tot_amts',store = True)#
    department_id = fields.Many2one('department.master',string = 'Department',compute=  'compute_tot_amts',store = True,readonly = False)
    purchased_by = fields.Many2one('res.partner',string="Purchased/Handovered By",compute=  'compute_tot_amts',store = True,readonly = False)
    payment_term = fields.Selection([('cash','Cash'),('cheque_pdc', 'Cheque'),('ptc', 'PDC'),('neft','NEFT'),('credit_mode','Credit'),('gpay/phonepay','Gpay/Phone Pay')],'Payment Method In Purchase of Mode',default="cash")
    due_date = fields.Datetime('Payment Due Date')
    Invoice_date = fields.Datetime('Invoice Date')
    invoice_date = fields.Datetime('Invoice Date')
    invoice_no = fields.Char('Invoice No')
    check_no = fields.Char('Cheque Number')
    rack_no = fields.Many2one('stock.location',string = 'Rack No')
    credit_period = fields.Integer('Credit Period in days')
    
     
    
    @api.onchange('credit_period')
    def due_date_calculate(self):
        if self.credit_period:
            self.due_date = datetime.now() + timedelta(days = self.credit_period) 
        else:
            self.due_date = False
       
    @api.depends('purchase_id')
    def compute_tot_amts(self):
        for each in self:  
            if each.purchase_id:
            
                vals_new_purchase=self.env['purchase.order'].search([('id','=',each.purchase_id[0].id)])

                # vals_new_sale = self.env['sale.order'].search([('id','=',each.sale_id[0].id)])
                val_request = self.env['purchase.request'].search([('purchase_order_id','=',vals_new_purchase.id)])
                
                if vals_new_purchase.payment_term == 'cheque':
                    self.payment_term = 'cheque_pdc'
                elif vals_new_purchase.payment_term == 'credit':
                     self.payment_term = 'credit_mode'
                elif vals_new_purchase:
                    self.payment_term = vals_new_purchase.payment_term
                else:
                    pass
                
                if vals_new_purchase or val_request:
                    self.purchased_by = vals_new_purchase.purchased_by.id
                    self.department_id = vals_new_purchase.department_id.id
                    self.invoice_no = vals_new_purchase.invoice_bill_no
                    self.invoice_date = vals_new_purchase.invoice_date
                    # raise ValidationError(vals_new_purchase.department_id.id)

                    val_request.delivery_date = each.date_deadline
                    val_request.loc_id = each.location_dest_id.id
                    each.tot_amt = float(vals_new_purchase.amount_untaxed)

                    l= []
                    j= []
                    for val in vals_new_purchase.order_line:
                       
                        l.append(val.price_unit)
                        j.append(val.price_subtotal)
                    if l and j:
                        for i in range(len(each.move_ids_without_package)):    
                            each.move_ids_without_package[i].unit_price = l[i]
                            each.move_ids_without_package[i].tot = j[i]
                    else:
                        pass
                # elif vals_new_sale:
                #     self.purchased_by = vals_new_sale.purchased_by
                #     each.tot_amt = float(vals_new_sale.amount_untaxed)
                #     each.department_id =  vals_new_sale.department_id.id
                #     l= []
                #     j= []
                #     for val in vals_new_sale.order_line:
                #         l.append(val.price_unit)
                #         j.append(val.price_subtotal)
                #     if l and j:  
                #         for i in range(len(each.move_ids_without_package)):    
                #             each.move_ids_without_package[i].unit_price = l[i]
                #             each.move_ids_without_package[i].tot = j[i]
                #     else:
                #         pass
                else:
                    pass
                
                # 
           

class stock_return_picking_inherit(models.TransientModel):
    _inherit = 'stock.return.picking' 
    
    reason =  fields.Char('Reason')

class  Res_Bank_Inherit(models.Model):
    _inherit = 'res.bank'
    branch = fields.Char('Branch Name')  
    attachment_id = fields.Binary(string = "Check Leaf" )
    attachment_fname = fields.Char(string  ='Check Leaf File')  
    
class stock_return_picking_inherit(models.Model):
    _inherit = 'stock.move' 
    
    reason =  fields.Char('Remarks/Rejected Reason')
    s_no  = fields.Integer('S.NO',compute = '_sequence_ref',store = True)
    unit_price = fields.Float('Cost Per Piece',)
    date_pdf = fields.Char('Date Planned',store = True,compute ='compute_date')
    tot = fields.Float('Total Cost For Pack',compute = 'onchange_grn_sale_percent',store =True)
    remain_qty = fields.Float('Quantity(Shortage)',compute = 'compute_remain',default = 0.0)
    hsn_code = fields.Char('HSN Code',related = 'product_id.l10n_in_hsn_code')
    partner_id =fields.Many2one('res.partner',string = 'Inspected By')
    description = fields.Text('Description',related = 'product_id.description')
    department = fields.Char(related = 'product_id.department.department',string = 'Department')
    pack_size = fields.Integer('Pack Size',related ='product_id.pack_size') 
    expanded_qty = fields.Integer('Total Cost Expanded',)
   
    sale_percent = fields.Integer('Sale Price In %')
    sale_value = fields.Float('Sale Value')
    
    
    @api.onchange('sale_percent','unit_price','quantity_done')
    def onchange_grn_sale_percent(self):
        for each in self:
            val= each.unit_price 
            self.sale_value =  val + ((val/100) *(((each.sale_percent*100)/100)))
            self.tot = self.quantity_done * self.unit_price
            
            
    @api.onchange('product_uom_qty','quantity_done')
    def compute_remain(self):
        for each in self:
            each.remain_qty  = each.product_uom_qty - each.quantity_done
           
    @api.depends('date')
    def compute_date(self):
        for rec in self:
            for each in rec:
                if each.date:
                    self.date_pdf = str(each.date.date().strftime("%d-%b-%Y"))    
                        
    @api.depends('picking_id.move_ids_without_package')
    def _sequence_ref(self):
       
        for line in self:
            no = 0
            for l in line.picking_id.move_ids_without_package:
                no += 1
                l.s_no = no
                    
class inherit_account_move_line(models.Model):
    _inherit = 'account.move.line'
        
    s_no = fields.Integer('S.NO',compute="_sequence_ref",store = True)
    hsn_code = fields.Char('HSN Code',related = 'product_id.l10n_in_hsn_code')
    sub_total_gst = fields.Monetary('Total with Gst',compute= '_tax_for_products',store=True)
    
    @api.depends('move_id.invoice_line_ids')
    def _sequence_ref(self):
        for line in self:
            no = 0
            for l in line.move_id.invoice_line_ids:
                no += 1
                l.s_no = no
      
    
    @api.depends('move_id.invoice_line_ids')
    def _tax_for_products(self):
        for line in self:

            for l in line.move_id.invoice_line_ids:
                if l.tax_ids:
                    k= (l.tax_ids[0].name)
                    if k:
                        if k[-3]!='':
                            o = int(k[-3]+k[-2])
                            l.sub_total_gst = l.price_subtotal *(o /100)
                        elif  int(k[-2]):
                            l.sub_total_gst = l.price_subtotal *(int(k[-2])/100)

                        else:
                            pass
                    else:
                        pass

                else:
                    pass        
    
            
class purchase_order_line(models.Model):
    _inherit = 'purchase.order.line'
    
    s_no = fields.Integer('S.NO',compute="_sequence_ref",store = True)
    hsn_code = fields.Char('HSN Code',related = 'product_id.l10n_in_hsn_code')
    make = fields.Char('Make')
    model_no = fields.Char('Model Number')
    sl_no = fields.Char('SL.NO',) 

    @api.depends('order_id.order_line')
    def _sequence_ref(self):
        for line in self:
            no = 0
            for l in line.order_id.order_line:
                no += 1
                l.s_no = no

    
      
class res_partner_inherit(models.Model):
    _inherit = 'res.partner'
    
    
    internal_engineer = fields.Selection([('internal','Internal Engineer'),('supplier','Supplier')],string = 'Person Type')
    gender = fields.Selection([('male','Male'),('female','Female')])
    check_rating = fields.Selection([('100%','Excellent(100%)'),('80%','Good(80%)'),('60%','Not Bad(60%)'),('50%','Bad(below 50%)')],string ='Rating',compute = 'get_check_rating')
    attachment_ids_1 = fields.Binary(string = "Check Leaf" )
    attachment_fname_1 = fields.Char(string  ='Check Leaf File')
    attachment_ids_2 = fields.Binary(string = "GST Certificate" )
    attachment_fname_2 = fields.Char(string  ='Gst File')
    attachment_ids_3 = fields.Binary(string = "Other Certificate" )
    attachment_fname_3 = fields.Char(string  ='Certificate File')
    attachment_ids_4 = fields.Binary(string = "Msme" )
    attachment_fname_4 = fields.Char(string  ='Msme File')
    
    
    # supplier = fields.Boolean('Supplier')
    # rating = fields.Selection([('0','Low'),('1','Medium'),('2','High'),('3','Very High')],string ='Vendor Rating')
    
    #value compute  function
    def get_check_rating(self):
        for each in self:
            rating = self.env['rating.form'].search([('partner_id', '=', self.id)],limit = 1)
            each.check_rating = rating.material_delivery_time
            
    #smart button object call action
    def vendor_rating(self):
        return   {'name': ('Vendor Rating Form'),
                      'type': 'ir.actions.act_window',
                      'res_model': 'rating.form',
                      'view_mode': 'tree,form',
                      'domain':[('partner_id', '=', self.id)], 
                      'context': "{'create': False}",
                      
                     }
        
class sale_order_line(models.Model):
    _inherit = 'sale.order.line'

    s_no  = fields.Integer('S.NO',compute = '_sequence_ref',store = True)
    
    sale_percent = fields.Integer('Sale Price In %')
    sale_date = fields.Datetime('Sale Date',related = 'order_id.date_order')
    department = fields.Many2one('department.master',string= 'Department',related = 'order_id.department_id')
    pack_size = fields.Integer('Pack Size',related ='product_id.pack_size') 
    date_of_purchase = fields.Datetime('Date of Purchase')
    purchased_by = fields.Many2one('res.partner',string="Purchased/Handovered By",related = 'order_id.purchased_by')
    sale_pack_qty = fields.Integer('Sale Pack Qty',)
    pack_inside_qty  = fields.Integer('Pack Inside Pieces Qty',)
    unit_pieces = fields.Integer('Unit For Pieces',)
    project_id = fields.Many2one('project.project',string = 'Project Name')
    
    
    
    @api.onchange('sale_percent','product_uom_qty','price_unit')
    def onchange_sale_percent(self):
        for each in self:
            val= each.price_subtotal
            self.price_subtotal = val + ((val/100) *(((each.sale_percent*100)/100)))

    @api.depends('order_id.order_line')
    def _sequence_ref(self):    
        for line in self:
            no = 0
            for l in line.order_id.order_line:
                no += 1
                l.s_no = no

class account_move_inherit(models.Model):
    _inherit = 'account.move'

    tot_in_words  =  fields.Char('Total In Words',compute = '_compute_amount_in_word',store = True)
    transport_charge = fields.Monetary('Transport Charge')
    round_off = fields.Float(string="Round Off", compute='_compute_amount_in_word',store = True)
    department_id = fields.Many2one('department.master',string = 'Department',compute ='compute_department',store = True)
    sale_type=fields.Selection([('spare_sale','Spare Sale'),('product_sale','Product sale')],string = 'Sale Type')

    terms_conditions = fields.Html('Terms And Conditions')

    terms_conditions_id = fields.Many2one('terms.conditions',"Terms and Conditions")

    amount_total_signed = fields.Monetary(compute='_compute_amount_total', string='Total Amount Signed', store=True)

    @api.onchange('ref')
    def _compute_amount_total(self):
        for move in self:
            move.amount_total_signed = abs(move.amount_total_signed)
   

    @api.onchange('terms_conditions_id')
    def terms_conditions_onchange(self):
        for rec in self:
            rec.terms_conditions = rec.terms_conditions_id.terms

    @api.depends('invoice_origin')
    def compute_department(self):
        for each in self:  
            if each.invoice_origin:
            
                vals_purchase=self.env['purchase.order'].search([('name','=',each.invoice_origin)])
                vals_sale = self.env['sale.order'].search([('name','=',each.invoice_origin)])
                if vals_purchase:
                   
                    self.department_id = vals_purchase.department_id.id
                    
                elif vals_sale:
                    
                    self.department_id =  vals_sale.department_id.id
                else:
                    pass   
                
    @api.depends('amount_total')
    def _compute_amount_in_word(self):
        for rec in self:
            rec.round_off = round(rec.amount_total)
            rec.tot_in_words ='Rupees '+ str(num2words(rec.round_off,lang='en_IN')).title()+ ' Only'
            

    @api.model
    def create(self,vals):
        result = super(account_move_inherit, self).create(vals)
        
        result.l10n_in_gst_treatment = 'consumer'
        return result

class project_inherit_task(models.Model):
    _inherit = 'project.task'
    
    sale_id = fields.Many2one('sale.order',string = 'Sale Reference')

class inherit_mrp_production(models.Model):
    _inherit = 'mrp.production'
    
    sale_id  = fields.Many2one('sale.order',readonly = True ,string = 'Sale Reference')
    customer_name  = fields.Char(related ='sale_id.partner_id.name',string= 'Customer')
    code = fields.Char(related ='product_id.l10n_in_hsn_code',string= 'Code')
    date_planned_start = fields.Datetime('Launch')
    stages = fields.Char(string='Stages',compute = 'onchange_line',store = True)
    work_order = fields.Char('Workorders',compute = 'onchange_line',store = True)
    consume = fields.Char('Consumed Products',compute = 'compute_consume',store = True)
    
    @api.depends('workorder_ids.name','workorder_ids.workcenter_id')
    def onchange_line(self):
        for each in self:
            if each.workorder_ids:
                names = each.workorder_ids.mapped('name')
                centers = each.workorder_ids.mapped('workcenter_id.name')
                val=''
                center =''
                for i in names:
                    val += i+','
                for j in centers:
                    center += j+',' 
                    
                self.work_order = val[0:-1]
                self.stages = center[0:-1]
                
          
    @api.depends('move_raw_ids.product_id','move_raw_ids.product_uom_qty','move_raw_ids.product_uom')
    def compute_consume(self):
        for each in self:
            if each.move_raw_ids:
                product = each.move_raw_ids.mapped('product_id.name')
                consume = each.move_raw_ids.mapped('product_uom_qty')
                l=[]
                for each_id in each.move_raw_ids:
                    l.append(each_id.product_uom.name)
                pr=''
                if product:
                    for i in range(len(product)):
                        pr += product[i]+','+str(consume[i])+','+ l[i] + ','
               
                    
                    self.consume = pr[0:-1]
                
        
    
         
                
            
            
class StockPick_Type_Inherited(models.Model):
    _inherit = 'stock.picking.type'
    
    code = fields.Selection(selection_add=[('return_operation', 'Return History'),('issue_operation', 'Issue History'),('purchase_report','Purchase Report'),
                                           ('tot_transaction','Consolidated Stock Transactions'),('out_transaction','Item Transactions Log'),('material_availability','Material Availability')], 
                            ondelete={'return_operation': 'cascade','issue_operation':'cascade','purchase_report':'cascade','tot_transaction':'cascade','out_transaction':'cascade','material_availability':'cascade'})
    count_issue = fields.Integer(string="Number Of Issue History", compute='_get_mo_counts_for_issue')
    count_return =  fields.Integer(string="Number Of Return  History", compute='_get_mo_counts_for_return')
    count_purchase_report = fields.Integer(string="Number Of Purchase Report", compute='_get_po_counts')
    count_tot_transactions = fields.Integer(string="Consolidated Stock Transactions", compute='_get_tot_counts_for_transactions')
    count_out_transactions = fields.Integer(string="Item Transactions Log", compute='_get_out_counts_for_transactions')
    count_material_avail = fields.Integer(string = 'Material Availability',compute = '_get_material_availability')
    
    # Kanban Return Action
    def transfer_checking_return_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Return History',
            'res_model': 'stock.picking',   
            'view_mode': 'tree,form',
            'domain': [('origin', 'like', 'Return of'),('state','=','done')],
            'context': "{'create': False}",
        }
         
    
    def _get_mo_counts_for_return(self):
        
        orm = self.env['stock.picking'].search_count([('origin','like','Return of'),('state','=','done')])
        self.count_return = orm
            
    # Kanban Issue Action
    def transfer_checking_issue_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Issue History',
            'res_model': 'stock.scrap',   
            'view_mode': 'tree,form',
            'domain': [('state','=','done')],
            'context': "{'create': False}",
        }
    
    def _get_mo_counts_for_issue(self):
        
        orm = self.env['stock.scrap'].search_count([('state','=','done')])
        self.count_issue = orm   
               
    #Kanban Purchase Action
    def transfer_checking_purchase_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Report',
            'res_model': 'purchase.order',   
            'view_mode': 'tree,form',
            'domain': [('state','=','purchase')],
           'context': "{'create': False}",
        }
    def _get_po_counts(self):
        
        orm = self.env['purchase.order'].search_count([('state','=','purchase')])
        self.count_purchase_report = orm
    
    #Total Transactions Action 
    def total_material_transactions_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Consolidated Stock Transactions',
            'res_model': 'stock.picking',   
            'view_mode': 'tree,form',
            'domain': [('state','=','done')],
           'context': "{'create': False}",
        }  
         
    def _get_tot_counts_for_transactions(self):
        
        orm = self.env['stock.picking'].search_count([('state','=','done')])
        self.count_tot_transactions = orm
    
    #Total Out Transactions Action    
    def out_material_transactions_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Item Trasactions Log',
            'res_model': 'stock.picking',   
            'view_mode': 'tree,form',
            'domain': [('picking_type_code','=','outgoing'),('state','=','done')],
            'context': "{'create': False}",
        }
        
    def _get_out_counts_for_transactions(self):
        
        orm = self.env['stock.picking'].search_count([('picking_type_code','=','outgoing'),('state','=','done')])
        self.count_out_transactions = orm
    # Material Availability Action
    def material_availability_action_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Material Availability',
            'res_model': 'product.product',   
            'view_mode': 'tree,form',
           
            'context': "{'create': False}",
        }
    def _get_material_availability(self):
        orm = self.env['product.product'].search_count([])
        self.count_material_avail = orm     
        
        
class TermsConditions(models.Model):
    _name = 'terms.conditions'
    _rec_name = 'conditions'
    
    conditions = fields.Char("Terms and Conditions")
    terms = fields.Html('Terms and Conditions')
    
class Stock_quant(models.Model):
    _inherit ='stock.quant'
    