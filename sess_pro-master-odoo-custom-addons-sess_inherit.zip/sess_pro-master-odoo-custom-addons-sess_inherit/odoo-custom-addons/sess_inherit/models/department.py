from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Deparmentmaster(models.Model):
    _name="department.master"
    _rec_name="department"
   
    department=fields.Char(string='Department',required=True)