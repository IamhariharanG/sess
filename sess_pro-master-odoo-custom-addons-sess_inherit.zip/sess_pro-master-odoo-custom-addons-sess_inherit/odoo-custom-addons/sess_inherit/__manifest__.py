{
    'name': 'SESS',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Machines and Equipment Management',
    'depends': ['web','sale','base','contacts','purchase','mail'],
    'data': [
        
        'views/product.xml',
        'views/product_template.xml',
        
        'views/res_partner_inherit.xml',  
        'security/ir.model.access.csv',
        'views/department_master.xml',
        'report/inherit_purchase_order.xml', 
        'report/pdf.xml', 
        'report/purchase_pdf.xml', 
        'report/invoice_pdf.xml',
        'report/delivery_challan_pdf.xml',
        'report/sale_pdf.xml',
        'report/purchase_request_report.xml',
        'report/bom_report.xml',
        'report/grn_report.xml',
        'report/material_transfer_note.xml',
        'report/material_return_note.xml',
        'report/material_inspection_note.xml',
        'report/sale_quotation_pdf.xml',
        'report/inherit_rfq.xml',
         'views/purchase.xml',
         'report/bin_card.xml',
         'report/stores_ledger.xml', 
         'views/rating.xml',
         'views/purchase_request.xml',
         'views/inventory_kanban_inherit.xml',
         
          'views/store_action.xml',
        'views/terms_conditions.xml',
        'views/sequence.xml',

        # 'views/breadcrumb.xml',
        
        
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.N",
    'installable': True,
    'auto_install': False,
    'application': True,
}
