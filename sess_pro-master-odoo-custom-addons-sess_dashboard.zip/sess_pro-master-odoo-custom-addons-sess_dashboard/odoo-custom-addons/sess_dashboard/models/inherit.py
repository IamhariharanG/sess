from odoo import fields, models, api, _
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError, ValidationError
from odoo.tools import email_split, float_is_zero



class inherit_amc_transaction(models.Model):
    _inherit = 'amc.transaction'

    
    @api.model
    def update_records(self):
        data = datetime.now().strftime("%B")
        records = self.env['dashboard.block'].search([('name','=','Amc This Month')])
        records.write({'filter': [["month_name","=",str(data)]]})