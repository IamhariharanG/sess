{
    'name': 'SESS Dashboard',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Dashboard Management',
    'depends': ['sess_inherit_service'],
    'data': ['views/dashboard.xml',
        
    ],
  
    'author': "Scopex pvt.ltd,Hariharan.N",
    'installable': True,
    'auto_install': False,
    'application': True,
}
